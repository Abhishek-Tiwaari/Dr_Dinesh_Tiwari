<?php /* Loops through all portfolio, taxes, .. and display posts */

/**
 * The template for displaying taxonomies
 *
 * 
 * @package    Auxin
 * @license    LICENSE.txt
 * @author     
 * @link       http://averta.net/phlox/
 * @copyright  (c) 2010-2017 
*/
include 'taxonomy-news-category.php';
