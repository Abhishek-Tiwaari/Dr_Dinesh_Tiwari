<?php
/**
 * Admin functions
 *
 * 
 * @package    Auxin
 * @license    LICENSE.txt
 * @author     averta <info@averta.net> (www.averta.net)
 * @link       http://averta.net/phlox/
 * @copyright  (c) 2010-2022 averta <info@averta.net> (www.averta.net)
 */
