<?php
/**
 * Silence is gold
 */