<?php

// commeon functions
include_once( 'general-functions.php' );
include_once( 'general-hooks.php' );

// load shortcode files
include_once( 'general-shortcodes.php' );

include_once( 'classes/class-auxpfo-template-loader.php' );


// load elements
include_once( 'elements/recent-portfolios.php' );
include_once( 'elements/recent-portfolios-tile-carousel.php' );
include_once( 'elements/recent-portfolios-grid-carousel.php' );

include_once( 'elements/elementor/class-auxpfo-elementor-elements.php' );
